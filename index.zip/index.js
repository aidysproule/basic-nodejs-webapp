const http = require('http');
const randomstring = require("randomstring");
const random_name = require('node-random-name');
const slugify = require('slugify');

var httpString;



const server = http.createServer((req,res) => {
    httpString = randomstring.generate() + "\n";
    httpString = httpString+ random_name() + "\n";
    httpString = httpString+ slugify(httpString,"-") + "\n";
    res.end(httpString);
});

server.listen(8000, '0.0.0.0', ()=> {
    console.log('Listening for requests on port 8000');
})